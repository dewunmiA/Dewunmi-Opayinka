import React from 'react';
import { BRAND_IMAGES } from '../constants';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-white px-6 lg:px-16 overflow-hidden relative">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          
          {/* Image Column */}
          <div className="relative order-2 md:order-1 reveal">
             {/* Decorative Blobs */}
             <div className="absolute -top-10 -right-10 w-48 h-48 bg-brandGold rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-blob"></div>
             <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-brandNavy rounded-full mix-blend-multiply filter blur-xl opacity-10 animate-blob animation-delay-2000"></div>
             
             <div className="absolute top-4 left-4 w-full h-full border-2 border-brandGold/30 translate-x-4 translate-y-4 rounded-lg"></div>
             <div className="relative h-[600px] overflow-hidden bg-gray-100 shadow-2xl rounded-lg z-10">
               <img 
                 src={BRAND_IMAGES.about} 
                 alt="Dewunmi Aisha Portrait" 
                 className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-700"
               />
             </div>
          </div>

          {/* Text Column */}
          <div className="order-1 md:order-2 text-center md:text-left">
            <h2 className="text-3xl md:text-5xl font-serif font-bold text-brandNavy mb-8 leading-tight reveal">
              Social Impact and <span className="text-brandGold">Partnerships Strategist.</span>
            </h2>
            <div className="h-1.5 w-20 bg-brandGold mx-auto md:mx-0 mb-8 reveal rounded-full" style={{ transitionDelay: '0.2s' }}></div>
            
            <p className="text-lg text-gray-600 leading-relaxed font-light mb-6 reveal" style={{ transitionDelay: '0.4s' }}>
              I am a futurist and impact architect who helps leaders, creators, and institutions design, communicate, and deliver impact and legacy that outlives them.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed font-light mb-8 reveal" style={{ transitionDelay: '0.6s' }}>
              As the Founder of <a href="https://www.meridianimpactfund.com" target="_blank" rel="noopener noreferrer" className="text-brandGold font-bold hover:underline">Meridian Impact Fund</a>, my work spans anticipation of where policy, philanthropy, and creative economies are headed. I convene governments, foundations, and the private sector to turn conversations into coalitions, and I coach high-capacity individuals to design careers that compound into legacy, not just achievements.
            </p>
            
            <div className="flex justify-center md:justify-start space-x-4 reveal" style={{ transitionDelay: '0.8s' }}>
              <div className="text-center px-4 py-2 border-r border-gray-200">
                <span className="block text-2xl font-bold text-brandNavy">15+</span>
                <span className="text-xs uppercase text-gray-500 tracking-wider">Years Exp.</span>
              </div>
              <div className="text-center px-4 py-2">
                <span className="block text-2xl font-bold text-brandNavy">$100M+</span>
                <span className="text-xs uppercase text-gray-500 tracking-wider">Portfolio Managed</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;