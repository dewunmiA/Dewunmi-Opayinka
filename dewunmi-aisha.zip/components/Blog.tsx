import React from 'react';
import { Link } from 'react-router-dom';
import { BLOG_POSTS } from '../constants';

const Blog: React.FC = () => {
  // Get the 4 most recent posts (assuming BLOG_POSTS is chronological ascending, we reverse it to get newest first)
  const recentPosts = [...BLOG_POSTS].reverse().slice(0, 4);

  return (
    <section id="blog" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <h2 className="text-3xl font-serif font-bold text-gray-900 mb-2">My Blog</h2>
        <div className="h-1 w-12 bg-emerald-500 mx-auto mb-16"></div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {recentPosts.map((post) => (
            <Link 
              to={`/blog/${post.id}`} 
              key={post.id} 
              className="bg-white shadow-sm hover:shadow-lg transition-shadow duration-300 overflow-hidden text-left group block flex flex-col h-full"
            >
              <div className="h-48 overflow-hidden relative flex-shrink-0">
                <img 
                  src={post.imageUrl} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-300"></div>
              </div>
              <div className="p-6 flex flex-col flex-grow">
                <span className="text-xs text-emerald-500 font-bold uppercase tracking-wider mb-2 block">{post.date}</span>
                <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-emerald-600 transition-colors line-clamp-2">{post.title}</h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3 leading-relaxed flex-grow">{post.excerpt}</p>
                <span className="text-xs font-bold text-gray-900 uppercase tracking-widest group-hover:text-emerald-600 inline-block border-b border-transparent group-hover:border-emerald-600 transition-all pb-0.5 self-start">
                  Read More
                </span>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-16">
          <Link 
            to="/blog" 
            className="inline-block px-10 py-4 bg-transparent border border-gray-900 text-gray-900 font-bold text-xs uppercase tracking-widest hover:bg-gray-900 hover:text-white transition-all duration-300 rounded"
          >
            View All Insights
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Blog;