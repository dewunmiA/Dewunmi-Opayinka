import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BLOG_POSTS } from '../constants';

const BlogDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const post = BLOG_POSTS.find(p => p.id === id);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!post) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-3xl font-serif font-bold text-gray-900 mb-4">Post Not Found</h2>
          <Link to="/" className="text-emerald-600 hover:text-emerald-800 font-bold uppercase tracking-widest">
            Return Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <article className="min-h-screen bg-white pt-32 pb-24">
      {/* Header Image */}
      <div className="w-full h-[400px] md:h-[500px] relative mb-16">
        <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="max-w-4xl px-6 text-center text-white">
            <span className="block text-emerald-400 font-bold uppercase tracking-widest mb-4">{post.date}</span>
            <h1 className="text-4xl md:text-6xl font-serif font-bold leading-tight">{post.title}</h1>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-6">
        <div className="prose prose-lg prose-emerald text-gray-600 font-light leading-relaxed whitespace-pre-line">
          {post.content}
        </div>

        <div className="mt-16 pt-8 border-t border-gray-100 flex justify-between items-center">
          <Link to="/" className="text-emerald-600 font-bold uppercase tracking-widest text-sm hover:text-emerald-800 transition-colors">
            ← Back to Home
          </Link>
        </div>
      </div>
    </article>
  );
};

export default BlogDetail;