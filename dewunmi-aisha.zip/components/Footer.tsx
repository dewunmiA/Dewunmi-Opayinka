import React from 'react';
import { Icons } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white py-12 text-center text-gray-500 border-t border-gray-100">
      <div className="flex justify-center space-x-6 mb-8">
        <a href="https://linkedin.com/in/dewunmiaisha" target="_blank" rel="noreferrer" className="text-brandNavy hover:text-brandGold transition-colors"><Icons.LinkedIn /></a>
        <a href="https://twitter.com/dewunmiaisha" target="_blank" rel="noreferrer" className="text-brandNavy hover:text-brandGold transition-colors"><Icons.Twitter /></a>
        <a href="https://instagram.com/dewunmiaisha" target="_blank" rel="noreferrer" className="text-brandNavy hover:text-brandGold transition-colors"><Icons.Instagram /></a>
      </div>
      <p className="text-sm">
        &copy; {new Date().getFullYear()} Dewunmi Aisha. All Rights Reserved.
      </p>
    </footer>
  );
};

export default Footer;