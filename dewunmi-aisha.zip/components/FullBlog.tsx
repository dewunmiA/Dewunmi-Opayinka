import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BLOG_POSTS } from '../constants';

const FullBlog: React.FC = () => {
  // Show all posts, newest first
  const allPosts = [...BLOG_POSTS].reverse();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 pt-32 pb-24">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-gray-900 mb-6">All Insights</h1>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg font-light">
            Exploring the intersection of policy, partnership, and sustainable development.
          </p>
          <div className="h-1 w-12 bg-emerald-500 mx-auto mt-8"></div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
          {allPosts.map((post) => (
            <Link 
              to={`/blog/${post.id}`} 
              key={post.id} 
              className="bg-white shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden text-left group block flex flex-col h-full rounded-lg"
            >
              <div className="h-64 overflow-hidden relative flex-shrink-0">
                <img 
                  src={post.imageUrl} 
                  alt={post.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-300"></div>
              </div>
              <div className="p-8 flex flex-col flex-grow">
                <span className="text-xs text-emerald-500 font-bold uppercase tracking-wider mb-3 block">{post.date}</span>
                <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-emerald-600 transition-colors line-clamp-3 leading-tight">{post.title}</h3>
                <p className="text-gray-600 text-base mb-6 line-clamp-4 leading-relaxed flex-grow">{post.excerpt}</p>
                <span className="text-xs font-bold text-gray-900 uppercase tracking-widest group-hover:text-emerald-600 inline-block border-b border-transparent group-hover:border-emerald-600 transition-all pb-0.5 self-start">
                  Read Article
                </span>
              </div>
            </Link>
          ))}
        </div>

        <div className="mt-20 text-center border-t border-gray-200 pt-10">
            <Link to="/" className="inline-flex items-center text-sm font-bold uppercase tracking-widest text-gray-500 hover:text-emerald-600 transition-colors">
                <span className="mr-2">←</span> Back to Home
            </Link>
        </div>
      </div>
    </div>
  );
};

export default FullBlog;