import React from 'react';
import { BRAND_IMAGES } from '../constants';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center bg-brandCream overflow-hidden pt-28 lg:pt-0">
       
       {/* Background: Subtle Professional Grid Pattern */}
       <div className="absolute inset-0 opacity-[0.03] pointer-events-none">
          <svg width="100%" height="100%">
            <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="currentColor" strokeWidth="1.5"/>
            </pattern>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
       </div>
       
       {/* Decorative Gradient Glows - Minimal */}
       <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-brandGold/5 rounded-full blur-[100px] pointer-events-none"></div>
       <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-brandNavy/5 rounded-full blur-[100px] pointer-events-none"></div>

       <div className="max-w-7xl mx-auto px-6 w-full grid lg:grid-cols-2 gap-12 lg:gap-24 items-center relative z-10">
          
          {/* Text Content */}
          <div className="flex flex-col items-center lg:items-start text-center lg:text-left order-2 lg:order-1">
            
            <div className="inline-flex items-center gap-3 mb-8">
               <div className="h-[1px] w-12 bg-brandGold"></div>
               <span className="text-[11px] font-bold uppercase tracking-[0.3em] text-brandNavy">
                 Impact Strategist & Futurist
               </span>
            </div>

            <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif text-brandNavy mb-8 leading-none tracking-tight">
              DEWUNMI <br /> <span className="text-transparent bg-clip-text bg-gradient-to-r from-brandNavy to-brandGold">AISHA</span>
            </h1>
            
            <p className="text-gray-600 text-lg md:text-xl max-w-lg mb-10 font-light leading-relaxed">
              Architecting the systems, partnerships, and policies that power sustainable development in Africa and beyond.
            </p>

            <div className="flex flex-col sm:flex-row gap-5 w-full sm:w-auto">
              <a href="#contact" className="px-8 py-4 bg-brandNavy text-white text-xs font-bold uppercase tracking-[0.25em] hover:bg-brandGold hover:text-brandNavy transition-all duration-300 rounded-sm shadow-xl">
                Partner With Me
              </a>
            </div>
          </div>

          {/* Image Content - Professional Portrait Style */}
          <div className="relative order-1 lg:order-2 flex justify-center lg:justify-end">
             <div className="relative w-full max-w-[400px] aspect-[3/4]">
                {/* Professional Frame Effect */}
                <div className="absolute top-5 right-5 w-full h-full border-2 border-brandGold/30 rounded-sm z-0"></div>
                
                {/* Main Image */}
                <div className="relative z-10 w-full h-full bg-gray-200 shadow-2xl rounded-sm overflow-hidden">
                   <img 
                     src={BRAND_IMAGES.hero} 
                     alt="Dewunmi Aisha" 
                     className="w-full h-full object-cover object-top transform hover:scale-105 transition-transform duration-[1.5s] ease-out"
                   />
                   
                   {/* Subtle Overlay Gradient for style */}
                   <div className="absolute inset-0 bg-gradient-to-t from-brandNavy/30 to-transparent opacity-60"></div>
                </div>
             </div>
          </div>
       </div>
    </section>
  );
};

export default Hero;