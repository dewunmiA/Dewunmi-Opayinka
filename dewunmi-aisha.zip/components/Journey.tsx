import React from 'react';
import { CAREER_ITEMS, EDUCATION_ITEMS } from '../constants';

const Journey: React.FC = () => {
  return (
    <section id="journey" className="py-24 bg-white px-6 lg:px-16 border-t border-gray-100">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16 text-center">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">Professional Journey</h2>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16">
          
          {/* Experience Column */}
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-8 border-b border-gray-200 pb-4">Experience</h3>
            <div className="space-y-12 border-l border-emerald-100 pl-8 ml-4">
              {CAREER_ITEMS.map((item, index) => {
                 const itemWithLink = item as { role: string; company: string; description: string; link?: string };
                 return (
                  <div key={index} className="relative">
                    <span className="absolute -left-[41px] top-1.5 h-5 w-5 rounded-full border-4 border-white bg-emerald-500 shadow-sm"></span>
                    <div className="mb-2">
                      <h4 className="text-xl font-serif font-bold text-gray-900">{item.role}</h4>
                    </div>
                    <h5 className="text-sm font-bold text-gray-500 uppercase tracking-widest mb-4">
                      {itemWithLink.link ? (
                        <a href={itemWithLink.link} target="_blank" rel="noopener noreferrer" className="hover:text-emerald-600 transition-colors">
                          {item.company}
                        </a>
                      ) : (
                        item.company
                      )}
                    </h5>
                    <p className="text-gray-600 leading-relaxed text-sm">
                      {item.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Education & Certifications Column */}
          <div>
            <div className="sticky top-24 space-y-12">
               <div>
                 <h3 className="text-2xl font-bold text-gray-900 mb-8 border-b border-gray-200 pb-4">Education & Certifications</h3>
                 <div className="grid gap-6">
                   {EDUCATION_ITEMS.map((edu, index) => (
                     <div key={index} className="bg-gray-50 p-6 rounded border border-gray-100 hover:border-emerald-200 transition-colors">
                       <h4 className="font-bold text-gray-900 mb-2">{edu.degree}</h4>
                       <p className="text-sm text-gray-500">{edu.year}</p>
                     </div>
                   ))}
                 </div>
               </div>

               <div className="bg-emerald-900 p-8 rounded text-white text-center">
                 <h4 className="text-xl font-serif font-bold mb-4">Core Capabilities</h4>
                 <div className="flex flex-wrap justify-center gap-2">
                   {[
                     "Resource Mobilization", "Donor Mapping", "Proposal Writing", 
                     "Stakeholder Engagement", "Advocacy", "Partnership Building"
                   ].map((skill, i) => (
                     <span key={i} className="text-xs font-bold bg-white/10 px-3 py-1 rounded-full border border-white/20">
                       {skill}
                     </span>
                   ))}
                 </div>
               </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Journey;