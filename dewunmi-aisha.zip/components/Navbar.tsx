import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { NAV_ITEMS } from '../constants';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);

      if (isHome) {
        // ScrollSpy Logic
        const sections = NAV_ITEMS.map(item => item.href.substring(1));
        let current = '';
        for (const section of sections) {
          const element = document.getElementById(section);
          if (element && window.scrollY >= (element.offsetTop - 150)) {
            current = section;
          }
        }
        if (current) setActiveSection(current);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isHome]);

  const handleNavClick = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    setIsMobileMenuOpen(false);
    
    const targetId = href.substring(1);
    
    if (isHome) {
      const element = document.getElementById(targetId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    } else {
      navigate('/', { state: { targetId } });
    }
  };

  // Logic: 
  // Background: Transparent at top, White with shadow on scroll
  // Text: ALWAYS Navy (since background is Cream/White)
  
  const navClasses = (isHome && !isScrolled) 
    ? 'bg-transparent py-6' 
    : 'bg-white shadow-md py-4';
    
  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${navClasses}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <Link to="/" className="text-2xl font-serif font-bold tracking-tighter text-brandNavy">
          DEWUNMI<span className="text-brandGold">.</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex space-x-8">
          {NAV_ITEMS.map((item) => {
            const isActive = isHome && activeSection === item.href.substring(1);
            
            return (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className={`text-xs font-bold uppercase tracking-widest transition-colors duration-300 cursor-pointer ${
                  isActive ? 'text-brandGold' : 'text-brandNavy hover:text-brandGold'
                }`}
              >
                {item.label}
              </a>
            );
          })}
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-2xl focus:outline-none text-brandNavy"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <span>☰</span>
        </button>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden bg-white overflow-hidden transition-all duration-300 ${isMobileMenuOpen ? 'max-h-96 shadow-lg' : 'max-h-0'}`}>
        <div className="flex flex-col p-6 space-y-4">
          {NAV_ITEMS.map((item) => (
            <a
              key={item.label}
              href={item.href}
              onClick={(e) => handleNavClick(e, item.href)}
              className="text-sm font-bold uppercase text-brandNavy hover:text-brandGold block border-b border-gray-100 pb-2"
            >
              {item.label}
            </a>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;