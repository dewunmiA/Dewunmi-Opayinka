import React from 'react';
import { Icons } from '../constants';

const Philosophy: React.FC = () => {
  return (
    <section id="philosophy" className="py-24 bg-light px-6 lg:px-16">
      <div className="max-w-6xl mx-auto">
        
        {/* Section Header */}
        <div className="mb-16 reveal">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900 mb-8">My Philosophy & IP</h2>
          <p className="text-gray-600 leading-relaxed max-w-3xl text-lg font-light">
            Strategy is not an academic exercise; it is the essential bridge between vision and lasting change.
            My work is rooted in <strong>Impact-by-Design</strong>—not random CSR, but intentional ecosystem-building that aligns policy, capital, and community to create legacy that endures.
          </p>
        </div>

        {/* Services / Philosophy Cards */}
        <div className="grid md:grid-cols-3 gap-8">
          
          <div className="bg-white p-10 shadow-sm border-b-4 border-secondary group hover:-translate-y-2 transition-all duration-300 reveal rounded-t-lg">
            <div className="mb-6 bg-orange-50 w-20 h-20 rounded-full flex items-center justify-center group-hover:bg-secondary transition-colors duration-300">
               <div className="text-secondary group-hover:text-white transition-colors duration-300">
                 <Icons.Target />
               </div>
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-4 uppercase tracking-wide">ANCHOR Framework</h3>
            <p className="text-gray-500 text-sm leading-relaxed">
              A structured methodology I developed to <strong>Assess, Nurture, Connect, Harmonise, Organise, and Reinforce</strong> collaboration. This ensures that impact is coordinated, fundable, and not just accidental.
            </p>
          </div>

          <div className="bg-white p-10 shadow-sm border-b-4 border-accent group hover:-translate-y-2 transition-all duration-300 reveal rounded-t-lg" style={{ transitionDelay: '0.2s' }}>
             <div className="mb-6 bg-emerald-50 w-20 h-20 rounded-full flex items-center justify-center group-hover:bg-accent transition-colors duration-300">
               <div className="text-accent group-hover:text-white transition-colors duration-300">
                 <Icons.Globe />
               </div>
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-4 uppercase tracking-wide">Impact-by-Design</h3>
            <p className="text-gray-500 text-sm leading-relaxed">
              Moving beyond one-off projects to intentional ecosystem building. I help design policies, partnerships, and funding flows that sustain change across borders.
            </p>
          </div>

          <div className="bg-white p-10 shadow-sm border-b-4 border-gray-900 group hover:-translate-y-2 transition-all duration-300 reveal rounded-t-lg" style={{ transitionDelay: '0.4s' }}>
             <div className="mb-6 bg-gray-50 w-20 h-20 rounded-full flex items-center justify-center group-hover:bg-gray-900 transition-colors duration-300">
               <div className="text-gray-600 group-hover:text-white transition-colors duration-300">
                 <Icons.Leaf />
               </div>
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-4 uppercase tracking-wide">Legacy as a System</h3>
            <p className="text-gray-500 text-sm leading-relaxed">
              Legacy is not just end-of-life philanthropy. It is the living system of relationships, tools, platforms, and people I help you build over time that outlives you.
            </p>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Philosophy;