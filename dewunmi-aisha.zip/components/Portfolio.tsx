import React, { useState } from 'react';
import { PORTFOLIO_ITEMS } from '../constants';
import { PortfolioItem } from '../types';

const Portfolio: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);

  const scrollToContact = (e: React.MouseEvent) => {
    e.preventDefault();
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="portfolio" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <h2 className="text-3xl font-serif font-bold text-gray-900 mb-2">Recent Projects</h2>
        <div className="h-1 w-12 bg-emerald-500 mx-auto mb-16"></div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0">
          {PORTFOLIO_ITEMS.map((item) => (
            <div 
              key={item.id} 
              className="group relative h-64 overflow-hidden cursor-pointer bg-gray-900"
              onClick={() => setSelectedItem(item)}
            >
              <img 
                src={item.imageUrl} 
                alt={item.title} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-80 group-hover:opacity-40"
              />
              <div className="absolute inset-0 flex flex-col justify-center items-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-4">
                <span className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-2">{item.category}</span>
                <h3 className="text-white text-lg font-bold">{item.title}</h3>
                <div className="mt-4 w-8 h-8 rounded-full border border-white flex items-center justify-center">
                  <span className="text-white text-lg">+</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16">
          <button 
            onClick={scrollToContact}
            className="inline-block px-10 py-4 bg-emerald-600 text-white font-bold text-sm uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg hover:shadow-xl"
          >
            Hire Me
          </button>
        </div>
      </div>

      {/* Lightbox Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4" onClick={() => setSelectedItem(null)}>
          <div className="relative max-w-4xl w-full bg-white rounded-lg overflow-hidden" onClick={e => e.stopPropagation()}>
            <button 
              className="absolute top-4 right-4 text-gray-500 hover:text-gray-900 z-10 p-2 bg-white rounded-full"
              onClick={() => setSelectedItem(null)}
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
            <div className="grid md:grid-cols-2">
              <div className="h-64 md:h-96">
                <img src={selectedItem.imageUrl} alt={selectedItem.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-8 flex flex-col justify-center">
                <span className="text-emerald-600 text-xs font-bold uppercase tracking-widest mb-2">{selectedItem.category}</span>
                <h3 className="text-2xl font-serif font-bold text-gray-900 mb-4">{selectedItem.title}</h3>
                <p className="text-gray-600 mb-6">
                  My comprehensive project demonstrating impact and strategic collaboration in the {selectedItem.category.toLowerCase()} sector.
                </p>
                
                {/* Removed Dead Link Button */}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Portfolio;