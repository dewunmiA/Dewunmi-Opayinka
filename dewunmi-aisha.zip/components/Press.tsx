import React from 'react';
import { AWARDS } from '../constants';

const Press: React.FC = () => {
  return (
    <section id="press" className="py-24 bg-white px-6 lg:px-16 border-t border-gray-100">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-sm font-bold text-emerald-600 uppercase tracking-widest mb-2">In the Press</h2>
        <h3 className="text-3xl font-serif font-bold text-dark mb-12">Recognition & Impact</h3>

        <div className="grid sm:grid-cols-2 gap-6">
          {AWARDS.map((award, index) => (
            <div key={index} className="border border-gray-200 p-6 rounded hover:bg-gray-50 transition-colors">
              <div className="text-4xl text-emerald-200 mb-4 opacity-50">❝</div>
              <h4 className="text-lg font-bold text-gray-900 mb-1">{award.title}</h4>
              <p className="text-sm text-gray-500 uppercase tracking-wide">by {award.organization}</p>
            </div>
          ))}
        </div>
        
        <p className="mt-12 text-gray-500 italic text-sm">
          "Celebrating leadership and professional excellence in the corporate and development sectors across Africa."
        </p>
      </div>
    </section>
  );
};

export default Press;