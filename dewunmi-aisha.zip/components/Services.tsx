import React, { useState } from 'react';
import { OFFERINGS, Icons } from '../constants';

const Services: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  // Identify the target offering title to gate
  const GATE_TITLE = "Partnership Readiness Checklist";

  const handleClick = (e: React.MouseEvent, offer: typeof OFFERINGS[0]) => {
    if (offer.title === GATE_TITLE) {
      e.preventDefault();
      setIsModalOpen(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real application, you would send this data to your newsletter API (e.g. Mailchimp, ConvertKit)
    console.log("Captured lead:", { name, email });
    setIsSubmitted(true);
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setTimeout(() => {
        setIsSubmitted(false);
        setEmail('');
        setName('');
    }, 300);
  };

  return (
    <section id="services" className="py-24 bg-light px-6 lg:px-16 relative">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <div className="mb-16 text-center">
          <span className="block text-xs font-bold text-gray-400 uppercase tracking-[0.2em] mb-3">Work With Me</span>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-brandNavy">Strategic Offerings</h2>
          <div className="h-1.5 w-12 bg-brandGold mx-auto mt-6 rounded-full"></div>
        </div>

        {/* Offerings Grid */}
        <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {OFFERINGS.map((offer, index) => {
            const isConsulting = offer.type === 'consulting';
            const isFreebie = offer.price === 'Free';
            const isGated = offer.title === GATE_TITLE;
            
            return (
              <div 
                key={index} 
                className={`relative p-8 rounded-xl transition-all duration-300 border flex flex-col group hover:-translate-y-2 ${
                  isConsulting 
                    ? 'bg-brandNavy text-white border-brandNavy shadow-2xl' 
                    : 'bg-white text-gray-900 border-gray-100 shadow-lg'
                }`}
              >
                {/* Badge for Digital Product */}
                {!isConsulting && (
                  <div className={`absolute top-0 right-0 text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-tr-xl rounded-bl-xl ${isFreebie ? 'bg-green-600 text-white' : 'bg-brandGold text-brandNavy'}`}>
                    Web Application
                  </div>
                )}
                
                {/* Header */}
                <div className="flex items-start justify-between mb-6">
                  <div>
                     <h3 className={`text-xl font-serif font-bold mb-2 ${isConsulting ? 'text-white' : 'text-brandNavy'}`}>
                       {offer.title}
                     </h3>
                     {offer.price && (
                       <div className="flex items-baseline gap-1">
                         <span className={`text-3xl font-bold ${isConsulting ? 'text-brandGold' : 'text-brandGold'}`}>
                           {offer.price}
                         </span>
                         <span className={`text-sm ${isConsulting ? 'text-gray-400' : 'text-gray-500'}`}>
                           {offer.frequency}
                         </span>
                       </div>
                     )}
                  </div>
                  <div className={`p-3 rounded-full transition-colors ${isConsulting ? 'bg-white/10 group-hover:bg-brandGold group-hover:text-brandNavy' : 'bg-orange-50 text-brandGold group-hover:bg-brandGold group-hover:text-white'}`}>
                    {isConsulting ? <Icons.Calendar /> : <Icons.Laptop />}
                  </div>
                </div>

                <p className={`mb-8 leading-relaxed text-sm flex-grow ${isConsulting ? 'text-gray-300' : 'text-gray-600'}`}>
                  {offer.description}
                </p>

                {/* Features List */}
                <ul className="space-y-4 mb-10">
                  {offer.features?.map((feature, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-3 text-sm">
                      <span className={`flex-shrink-0 w-2 h-2 rounded-full mt-1.5 ${isConsulting ? 'bg-brandGold' : 'bg-brandNavy'}`} />
                      <span className={isConsulting ? 'text-gray-300' : 'text-gray-600'}>{feature}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA Button */}
                <a 
                  href={offer.link}
                  target={isGated ? undefined : "_blank"}
                  rel={isGated ? undefined : "noopener noreferrer"}
                  onClick={(e) => handleClick(e, offer)}
                  className={`block w-full py-4 text-center text-sm font-bold uppercase tracking-widest transition-all rounded-lg cursor-pointer ${
                    isConsulting
                      ? 'bg-brandGold text-brandNavy hover:bg-white shadow-lg'
                      : isFreebie
                        ? 'bg-brandNavy text-white hover:bg-brandNavy/90 shadow-lg'
                        : 'bg-gray-100 text-brandNavy hover:bg-gray-200'
                  }`}
                >
                  {offer.ctaText}
                </a>

                <p className="text-[10px] text-center mt-4 opacity-50">
                  {isConsulting ? 'Secure payment via Stripe • Instant Scheduling' : isFreebie ? 'Direct Browser Access • No Installation' : 'Secure Access • Cloud Based'}
                </p>
              </div>
            );
          })}
        </div>

        {/* Lead Magnet Modal */}
        {isModalOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
                {/* Backdrop */}
                <div className="absolute inset-0 bg-brandNavy/80 backdrop-blur-sm" onClick={handleClose}></div>
                
                {/* Modal Content */}
                <div className="relative bg-white rounded-lg shadow-2xl w-full max-w-md p-8 overflow-hidden animate-blob">
                    <button onClick={handleClose} className="absolute top-4 right-4 text-gray-400 hover:text-brandNavy transition-colors">
                        <Icons.Close />
                    </button>

                    {!isSubmitted ? (
                        <div>
                            <div className="w-12 h-12 bg-brandGold/10 rounded-full flex items-center justify-center text-brandGold mb-6">
                                <Icons.Laptop />
                            </div>
                            <h3 className="text-2xl font-serif font-bold text-brandNavy mb-2">Access The Assessment</h3>
                            <p className="text-gray-600 text-sm mb-6">
                                Enter your details below to instantly access the <strong>Partnership Readiness Checklist</strong> app.
                            </p>
                            
                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Name</label>
                                    <input 
                                        type="text" 
                                        required 
                                        value={name}
                                        onChange={(e) => setName(e.target.value)}
                                        className="w-full bg-gray-50 border border-gray-200 rounded p-3 text-brandNavy focus:outline-none focus:border-brandGold transition-colors"
                                        placeholder="Jane Doe"
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Email Address</label>
                                    <input 
                                        type="email" 
                                        required 
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        className="w-full bg-gray-50 border border-gray-200 rounded p-3 text-brandNavy focus:outline-none focus:border-brandGold transition-colors"
                                        placeholder="jane@example.com"
                                    />
                                </div>
                                <button type="submit" className="w-full bg-brandNavy text-white font-bold uppercase tracking-widest py-4 rounded hover:bg-brandGold hover:text-brandNavy transition-all shadow-lg mt-2">
                                    Launch App Now
                                </button>
                                <p className="text-[10px] text-gray-400 text-center">We respect your inbox. No spam, ever.</p>
                            </form>
                        </div>
                    ) : (
                        <div className="text-center py-8">
                            <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl animate-bounce">
                                ✓
                            </div>
                            <h3 className="text-2xl font-serif font-bold text-brandNavy mb-2">You're All Set!</h3>
                            <p className="text-gray-600 text-sm mb-8">
                                The checklist app is ready. Click the button below to start your assessment.
                            </p>
                            <a 
                                href="#" 
                                className="block w-full bg-brandGold text-brandNavy font-bold uppercase tracking-widest py-4 rounded hover:bg-brandNavy hover:text-white transition-all shadow-lg"
                                onClick={(e) => {
                                  e.preventDefault();
                                  setTimeout(handleClose, 1000);
                                  // In reality, this would be a real link
                                  alert("Launching App...");
                                }}
                            >
                                Launch Assessment
                            </a>
                        </div>
                    )}
                </div>
            </div>
        )}

      </div>
    </section>
  );
};

export default Services;