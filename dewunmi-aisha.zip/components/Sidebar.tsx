import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Icons, NAV_ITEMS, BRAND_IMAGES } from '../constants';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavClick = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    onClose();
    
    const targetId = href.substring(1);
    
    if (location.pathname === '/') {
      const element = document.getElementById(targetId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    } else {
      navigate('/', { state: { targetId } });
    }
  };

  return (
    <>
      {/* Mobile Overlay */}
      <div 
        className={`fixed inset-0 z-40 bg-black/60 backdrop-blur-sm transition-opacity md:hidden ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />

      {/* Sidebar Content */}
      <aside className={`
        fixed top-0 left-0 z-50 h-full w-[280px] bg-[#1a1a1a] text-center text-gray-400 shadow-2xl transition-transform duration-300 ease-in-out flex flex-col
        md:translate-x-0 md:w-[300px]
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Scrollable Area */}
        <div className="flex-1 overflow-y-auto py-10 px-6 scrollbar-hide">
          
          {/* Header / Profile */}
          <div className="mb-10">
            <div className="mx-auto h-40 w-40 overflow-hidden rounded-full border-[5px] border-[#2c2c2c] mb-6 shadow-xl relative group">
              <img 
                src={BRAND_IMAGES.sidebar} 
                alt="Dewunmi Aisha" 
                className="h-full w-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
              />
            </div>
            <h1 className="text-2xl font-serif font-bold text-white tracking-wide mb-2">
              Dewunmi<br/>Aisha
            </h1>
            <p className="text-[10px] uppercase tracking-widest text-emerald-500 font-bold leading-relaxed">
              Strategist • Futurist • Coach
            </p>
          </div>

          {/* Navigation */}
          <nav>
            <ul className="space-y-1">
              {NAV_ITEMS.map((item) => (
                <li key={item.label}>
                  <a 
                    href={item.href}
                    onClick={(e) => handleNavClick(e, item.href)}
                    className="block py-3 text-sm font-bold uppercase tracking-widest hover:text-emerald-500 transition-colors focus:text-emerald-500 cursor-pointer"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </div>

        {/* Footer */}
        <div className="py-6 px-6 border-t border-[#2c2c2c]">
          <div className="flex justify-center space-x-5 mb-4">
            <a href="https://linkedin.com/in/dewunmiaisha" target="_blank" rel="noreferrer" className="text-gray-400 hover:text-white transition-colors">
              <Icons.LinkedIn />
            </a>
          </div>
          <p className="text-[10px] text-gray-600 font-sans">
            &copy; {new Date().getFullYear()} Dewunmi Aisha.<br/>All rights reserved.
          </p>
        </div>

        {/* Mobile Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-white md:hidden hover:bg-white/10 rounded-full"
        >
          <Icons.Close />
        </button>
      </aside>
    </>
  );
};

export default Sidebar;