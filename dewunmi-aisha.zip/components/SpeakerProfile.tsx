import React, { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { BRAND_IMAGES, SPEAKING_GALLERY, TESTIMONIALS } from '../constants';

const SpeakerProfile: React.FC = () => {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Carousel Autoscroll
  useEffect(() => {
    const interval = setInterval(() => {
      if (!isPaused && scrollRef.current) {
        const { current } = scrollRef;
        const scrollAmount = 320; // Card width + gap
        
        const isAtEnd = current.scrollLeft + current.clientWidth >= current.scrollWidth - 10;
        
        if (isAtEnd) {
          current.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        }
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [isPaused]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { current } = scrollRef;
      const scrollAmount = 320; 
      if (direction === 'left') {
        current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
      } else {
        current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    }
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleBookClick = (e: React.MouseEvent) => {
    e.preventDefault();
    navigate('/', { state: { targetId: 'contact' } });
  };

  return (
    <div className="min-h-screen bg-white">
      
      {/* 1. HERO SECTION */}
      <section className="relative py-24 lg:py-32 bg-brandNavy text-white overflow-hidden">
        {/* Abstract Background Element */}
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-brandGold/5 rounded-full blur-[120px] pointer-events-none"></div>
        
        <div className="max-w-5xl mx-auto px-6 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold mb-4 tracking-tight">
            Dewunmi Aisha
          </h1>
          <h2 className="text-xl md:text-2xl text-brandGold font-bold uppercase tracking-widest mb-12">
            Social Impact & Partnerships Strategist
          </h2>
          
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button 
              onClick={() => scrollToSection('book')}
              className="px-8 py-4 bg-brandGold text-brandNavy font-bold uppercase tracking-widest hover:bg-white transition-all duration-300 shadow-lg"
            >
              Book Dewunmi to Speak
            </button>
            <a 
              href="https://drive.google.com/file/d/1cxMLaQ9f8p3uUF0f7gyLq1kwzx4M72f-/view"
              target="_blank"
              rel="noopener noreferrer"
              className="px-8 py-4 border border-white text-white font-bold uppercase tracking-widest hover:bg-white/10 transition-all duration-300"
            >
              Download Speaker Profile
            </a>
          </div>
        </div>
      </section>

      {/* 2. POSITIONING SNAPSHOT */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-3xl mx-auto text-center">
          <h3 className="text-2xl font-serif font-bold text-brandNavy mb-6">The Gap Between Intention and Impact</h3>
          <p className="text-lg text-gray-600 leading-relaxed mb-6 font-light">
            In the development sector, impact often fails not because of a lack of will, but because partnerships are poorly designed and incentives are misaligned. As an SDG 17 specialist, I design the collaboration systems that bridge these gaps. I architect the frameworks, governance, and funding models that turn isolated projects into sustainable ecosystems, delivering legacy that outlives the leader.
          </p>
          <p className="text-xl font-bold text-brandNavy border-t border-brandGold/30 pt-6 inline-block">
            Her work is anchored in SDG 17 – Partnerships for the Goals.
          </p>
        </div>
      </section>

      {/* 3. TOPICS GRID */}
      <section id="topics" className="py-20 px-6 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Expertise</span>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-brandNavy mt-2">Speaking Topics</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Partnerships as Infrastructure", promise: "How to design cross-sector alliances that outlive funding cycles." },
              { title: "Designing Sustainable Impact Systems", promise: "Moving from reactive problem-solving to proactive ecosystem architecture." },
              { title: "From Projects to Ecosystems", promise: "The strategic shift required to scale impact across borders." },
              { title: "Women as Architects of Power", promise: "Redefining leadership and economic influence in the global south." },
              { title: "Future of Work & AI for Social Impact", promise: "Leveraging technology to leapfrog development challenges." },
              { title: "Multipotential Leadership", promise: "Systems thinking for leaders navigating complex, high-stakes environments." }
            ].map((topic, idx) => (
              <div key={idx} className="bg-white p-8 border-l-4 border-brandGold shadow-sm hover:shadow-lg transition-all">
                <h3 className="text-xl font-bold text-brandNavy mb-3">{topic.title}</h3>
                <p className="text-gray-600 text-sm font-medium">{topic.promise}</p>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <button 
               onClick={() => scrollToSection('book')}
               className="text-brandNavy font-bold uppercase tracking-widest text-sm border-b-2 border-brandGold pb-1 hover:text-brandGold transition-colors"
            >
              Request Topic Details &rarr;
            </button>
          </div>
        </div>
      </section>

      {/* 4. CREDIBILITY & EXPERIENCE */}
      <section className="py-20 px-6 bg-brandNavy text-white">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-12">
            <div className="md:w-1/3">
              <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Authority &<br/>Experience</h2>
              <div className="h-1.5 w-16 bg-brandGold"></div>
            </div>
            <div className="md:w-2/3">
              <ul className="space-y-4">
                {[
                  "Designed multi-country programmes with UNDP",
                  "Mobilized $100M+ in partnerships at TEF",
                  "Led national advocacy campaigns (WEE, MNCH)",
                  "Advises governments, donors, corporates",
                  "Builds AI-enabled tools for impact ecosystems"
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start">
                    <span className="text-brandGold mr-3 text-xl">•</span>
                    <span className="text-lg font-light">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 5. SELECTED SPEAKING APPEARANCES */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-2xl font-serif font-bold text-brandNavy mb-12">Selected Engagements</h2>
          
          <div className="grid md:grid-cols-2 gap-x-12 gap-y-6 text-left max-w-3xl mx-auto">
            {[
              "United Nations Development Programme – Policy & leadership convenings",
              "Tony Elumelu Foundation – Partner summits & ecosystem forums",
              "Gates Foundation Goalkeepers Nigeria – Advocacy & development forums",
              "African Union youth & development dialogues",
              "Government leadership retreats and executive strategy sessions",
              "Women leadership and entrepreneurship conferences",
              "University and TEDx platforms"
            ].map((engagement, idx) => (
              <div key={idx} className="flex items-start border-b border-gray-100 pb-4">
                <span className="text-brandGold font-bold mr-3">0{idx + 1}</span>
                <p className="text-gray-700 font-medium text-sm">{engagement}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. SIGNATURE TALK */}
      <section className="py-20 px-6 bg-gray-900 text-white relative overflow-hidden">
        {/* Decorative background */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
            <svg width="100%" height="100%">
                <pattern id="pattern-circles" x="0" y="0" width="50" height="50" patternUnits="userSpaceOnUse">
                    <circle cx="25" cy="25" r="1" fill="#fff"/>
                </pattern>
                <rect x="0" y="0" width="100%" height="100%" fill="url(#pattern-circles)"/>
            </svg>
        </div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <span className="text-brandGold font-bold uppercase tracking-widest text-xs mb-4 block">Signature Keynote</span>
          <h2 className="text-4xl md:text-5xl font-serif font-bold mb-6">The Architecture of Impact</h2>
          <p className="text-gray-300 text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-10 font-light">
             A compelling deep dive into why good intentions aren't enough. Dewunmi dismantles the "pilot project paradox"—why brilliant initiatives fail to scale—and reveals the missing link: structural design. She walks audiences through the difference between "managing projects" and "architecting ecosystems," sharing real-world case studies from her work mobilizing over $100M across Africa.
          </p>
        </div>
      </section>

      {/* 7. AUDIENCE TAKEAWAYS */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-serif font-bold text-brandNavy text-center mb-12">What Audiences Gain</h2>
          
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-8 text-center">
            {[
              "Partnership design frameworks",
              "Practical systems thinking tools",
              "Clear language for cross-sector collaboration",
              "Strategy for sustainable delivery",
              "Real African case studies"
            ].map((takeaway, idx) => (
              <div key={idx} className="p-6 bg-gray-50 rounded-lg">
                <div className="w-10 h-10 bg-brandNavy text-white rounded-full flex items-center justify-center mx-auto mb-4 text-sm font-bold">✓</div>
                <p className="text-gray-800 font-medium">{takeaway}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. SPEAKING STYLE */}
      <section className="py-20 px-6 bg-gray-50 border-t border-gray-200">
        <div className="max-w-3xl mx-auto text-center">
           <h2 className="text-2xl font-serif font-bold text-brandNavy mb-8">Speaking Style</h2>
           <div className="flex flex-wrap justify-center gap-4">
             {["Clear, direct delivery", "Insightful, systems-oriented", "Practical frameworks", "Engaging without jargon"].map((style, idx) => (
               <span key={idx} className="px-6 py-3 bg-white shadow-sm rounded-full text-gray-700 font-bold text-sm border border-gray-100">
                 {style}
               </span>
             ))}
           </div>
        </div>
      </section>

      {/* 9. SPEAKING GALLERY */}
      <section className="py-20 px-6 bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto">
           <div className="flex justify-between items-end mb-8 px-2">
              <h3 className="text-2xl font-serif font-bold text-brandNavy uppercase tracking-widest">Speaking Gallery</h3>
              <div className="flex gap-2">
                 <button 
                   onClick={() => scroll('left')}
                   className="w-10 h-10 bg-white border border-gray-200 shadow-sm rounded-full flex items-center justify-center text-gray-600 hover:bg-brandGold hover:text-white hover:border-brandGold transition-all"
                 >
                   ←
                 </button>
                 <button 
                   onClick={() => scroll('right')}
                   className="w-10 h-10 bg-white border border-gray-200 shadow-sm rounded-full flex items-center justify-center text-gray-600 hover:bg-brandGold hover:text-white hover:border-brandGold transition-all"
                 >
                   →
                 </button>
              </div>
           </div>
           
           <div 
             className="relative"
             onMouseEnter={() => setIsPaused(true)}
             onMouseLeave={() => setIsPaused(false)}
           >
             <div 
               ref={scrollRef}
               className="flex overflow-x-auto space-x-6 pb-6 scrollbar-hide snap-x"
               style={{ scrollBehavior: 'smooth' }}
             >
               {SPEAKING_GALLERY.map((src, index) => (
                 <div 
                   key={index} 
                   className="flex-none w-[280px] h-[360px] bg-white rounded-sm shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden snap-center group relative"
                 >
                   <div className="absolute inset-0 bg-brandNavy/20 group-hover:bg-transparent transition-colors z-10"></div>
                   <img 
                     src={src} 
                     alt={`Speaking Engagement ${index + 1}`} 
                     className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                   />
                 </div>
               ))}
             </div>
           </div>
        </div>
      </section>
      
      {/* 10. WHAT PEOPLE SAY */}
      <section className="py-20 px-6 bg-gray-50 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-2">
           <h2 className="text-2xl font-serif font-bold text-brandNavy text-center mb-12 uppercase tracking-widest">What People Say</h2>
           
           <div className="grid md:grid-cols-3 gap-8">
             {TESTIMONIALS.map((item, idx) => (
               <div key={idx} className="bg-white p-8 rounded-sm shadow-sm hover:shadow-md transition-shadow">
                 <div className="mb-4 text-brandGold text-4xl font-serif leading-none">“</div>
                 <p className="text-gray-600 text-sm leading-relaxed mb-6 italic">
                   {item.quote}
                 </p>
                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-brandNavy text-white rounded-full flex items-center justify-center font-bold text-xs">
                      {item.author.charAt(0)}
                   </div>
                   <div>
                     <p className="text-sm font-bold text-brandNavy">{item.author}</p>
                     <p className="text-xs text-gray-500 uppercase tracking-wider">{item.role}</p>
                   </div>
                 </div>
               </div>
             ))}
           </div>
        </div>
      </section>

      {/* 11. FINAL CTA */}
      <section id="book" className="py-24 px-6 bg-brandNavy text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-brandGold/10 mix-blend-overlay"></div>
        <div className="max-w-4xl mx-auto relative z-10">
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-8 leading-tight">
            Bring systems thinking and partnership strategy to your next event.
          </h2>
          
          <div className="flex flex-col sm:flex-row justify-center gap-6 mb-12">
             <button 
               onClick={handleBookClick}
               className="px-10 py-5 bg-brandGold text-brandNavy font-bold uppercase tracking-widest hover:bg-white transition-all shadow-xl"
             >
               Book Dewunmi
             </button>
             <a 
               href="mailto:bookings@dewunmiaisha.com"
               className="px-10 py-5 bg-transparent border-2 border-white text-white font-bold uppercase tracking-widest hover:bg-white hover:text-brandNavy transition-all"
             >
               Contact via Email
             </a>
          </div>
        </div>
      </section>

    </div>
  );
};

export default SpeakerProfile;