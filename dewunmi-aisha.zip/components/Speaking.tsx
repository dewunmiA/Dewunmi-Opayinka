import React, { useRef, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { SPEAKING_TOPICS, ENGAGEMENTS, BRAND_IMAGES, SPEAKING_GALLERY } from '../constants';

const Speaking: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);

  const scrollToContact = (e: React.MouseEvent) => {
    e.preventDefault();
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { current } = scrollRef;
      // Scroll amount approximates card width + gap (140 + 16)
      const scrollAmount = 156; 
      if (direction === 'left') {
        current.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
      } else {
        current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
      }
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (!isPaused && scrollRef.current) {
        const { current } = scrollRef;
        const scrollAmount = 156;
        
        // Check if we've reached the end (with a small buffer)
        const isAtEnd = current.scrollLeft + current.clientWidth >= current.scrollWidth - 10;
        
        if (isAtEnd) {
          // Scroll back to start
          current.scrollTo({ left: 0, behavior: 'smooth' });
        } else {
          // Scroll next
          current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        }
      }
    }, 3000); // Scroll every 3 seconds

    return () => clearInterval(interval);
  }, [isPaused]);

  return (
    <section id="speaking" className="py-24 bg-light px-6 lg:px-16">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16 text-center">
          <span className="block text-xs font-bold text-gray-400 uppercase tracking-[0.2em] mb-3">Engagements</span>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-gray-900">Speaking & Leadership</h2>
        </div>

        <div className="grid lg:grid-cols-3 gap-10">
          
          {/* Image Column */}
          <div className="lg:col-span-1 h-full min-h-[400px]">
            <img 
              src={BRAND_IMAGES.speaking} 
              alt="Dewunmi Aisha Speaking" 
              className="w-full h-full object-cover shadow-xl"
            />
          </div>

          {/* Content Columns */}
          <div className="lg:col-span-2 flex flex-col justify-between">
            <div className="grid md:grid-cols-2 gap-10">
              
              {/* Topics */}
              <div>
                <h4 className="text-sm font-bold text-emerald-600 uppercase tracking-widest mb-6 border-b border-gray-200 pb-4">
                  Key Topics
                </h4>
                <div className="space-y-6">
                  {SPEAKING_TOPICS.map((topic, index) => (
                    <div key={index} className="flex group">
                      <span className="text-emerald-300 font-serif text-3xl mr-3 leading-none">"</span>
                      <p className="text-base text-gray-700 font-medium group-hover:text-gray-900 transition-colors pt-1">
                        {topic.title}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Appearances */}
              <div>
                <h4 className="text-sm font-bold text-emerald-600 uppercase tracking-widest mb-6 border-b border-gray-200 pb-4">
                  Selected Appearances
                </h4>
                <div className="space-y-4">
                  {ENGAGEMENTS.map((engage, index) => (
                    <div key={index} className="bg-white p-5 border-l-2 border-transparent hover:border-emerald-500 shadow-sm transition-all">
                      <p className="font-bold text-gray-900 text-sm mb-1">{engage.event}</p>
                      <p className="text-xs text-gray-500 uppercase tracking-wider">{engage.location}</p>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            <div className="mt-10 pt-8 border-t border-gray-200 flex flex-col sm:flex-row gap-4">
               <button 
                 onClick={scrollToContact}
                 className="flex-1 bg-gray-900 text-white px-8 py-4 text-sm font-bold uppercase tracking-widest hover:bg-emerald-600 transition-colors"
               >
                 Book an Engagement
               </button>
               <Link 
                 to="/speaker-profile"
                 className="flex-1 bg-white border border-gray-900 text-gray-900 px-8 py-4 text-sm font-bold uppercase tracking-widest hover:bg-gray-100 transition-colors text-center"
               >
                 View Speaker Profile
               </Link>
            </div>
          </div>

        </div>

        {/* Flier Carousel */}
        <div className="mt-24 pt-12 border-t border-gray-200">
           <div className="flex justify-between items-end mb-8 px-2">
              <h3 className="text-xl font-serif font-bold text-gray-900 uppercase tracking-widest">Speaking Gallery</h3>
              <div className="flex gap-2">
                 <button 
                   onClick={() => scroll('left')}
                   className="w-8 h-8 bg-white border border-gray-200 shadow-sm rounded-full flex items-center justify-center text-gray-600 hover:text-emerald-600 hover:border-emerald-600 transition-all"
                 >
                   ←
                 </button>
                 <button 
                   onClick={() => scroll('right')}
                   className="w-8 h-8 bg-white border border-gray-200 shadow-sm rounded-full flex items-center justify-center text-gray-600 hover:text-emerald-600 hover:border-emerald-600 transition-all"
                 >
                   →
                 </button>
              </div>
           </div>
           
           <div 
             className="relative"
             onMouseEnter={() => setIsPaused(true)}
             onMouseLeave={() => setIsPaused(false)}
           >
             <div 
               ref={scrollRef}
               className="flex overflow-x-auto space-x-4 pb-6 scrollbar-hide snap-x"
               style={{ scrollBehavior: 'smooth' }}
             >
               {SPEAKING_GALLERY.map((src, index) => (
                 <div 
                   key={index} 
                   className="flex-none w-[140px] h-[190px] bg-white rounded-lg shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden snap-center border border-gray-100 group"
                 >
                   <img 
                     src={src} 
                     alt={`Speaking Engagement ${index + 1}`} 
                     className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                   />
                 </div>
               ))}
             </div>
           </div>
        </div>

      </div>
    </section>
  );
};

export default Speaking;