import React, { useState } from 'react';
import { TESTIMONIALS } from '../constants';

const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const next = () => {
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const prev = () => {
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  return (
    <section className="py-20 bg-brandGold text-brandNavy">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h2 className="text-2xl font-serif font-bold mb-2">What People Say</h2>
        <div className="h-1 w-12 bg-brandNavy/20 mx-auto mb-8"></div>

        <div className="relative min-h-[150px] flex items-center justify-center">
          {/* Quote */}
          <div className="max-w-2xl px-12">
            <p className="text-xl md:text-2xl font-serif italic leading-relaxed mb-6">
              "{TESTIMONIALS[currentIndex].quote}"
            </p>
            <div className="font-bold uppercase tracking-widest text-xs opacity-80">
              {TESTIMONIALS[currentIndex].author}
            </div>
            <div className="text-xs mt-1 opacity-60">
              {TESTIMONIALS[currentIndex].role}
            </div>
          </div>

          {/* Controls */}
          <button 
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 p-3 hover:bg-brandNavy/10 rounded-full transition-colors"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          </button>
          <button 
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 p-3 hover:bg-brandNavy/10 rounded-full transition-colors"
          >
             <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
          </button>
        </div>

        {/* Dots */}
        <div className="flex justify-center space-x-2 mt-8">
          {TESTIMONIALS.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`w-2 h-2 rounded-full transition-all ${idx === currentIndex ? 'bg-brandNavy w-4' : 'bg-brandNavy/30'}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;