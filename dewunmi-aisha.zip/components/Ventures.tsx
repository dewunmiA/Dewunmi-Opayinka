import React from 'react';
import { VENTURES, Icons } from '../constants';

const Ventures: React.FC = () => {
  const Graphic1 = () => (
    <svg className="w-full h-8 text-white/20 absolute top-0 left-0" viewBox="0 0 100 20" preserveAspectRatio="none">
      <path d="M0 20 C 30 10 70 30 100 0 L 100 0 L 0 0 Z" fill="currentColor" />
    </svg>
  );

  const Graphic2 = () => (
    <svg className="w-full h-8 text-white/20 absolute top-0 left-0" viewBox="0 0 100 20" preserveAspectRatio="none">
      <path d="M0 0 L 100 0 L 100 15 Q 50 25 0 15 Z" fill="currentColor" />
    </svg>
  );

  const graphics = [Graphic1, Graphic2];

  return (
    <section id="portfolio" className="py-24 bg-white px-6 lg:px-16 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12 text-center md:text-left reveal">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-brandNavy mb-4">My Impact Portfolio</h2>
          <p className="text-gray-500 max-w-2xl">A selection of my multi-stakeholder initiatives and strategic interventions that bridge the gap between policy and prosperity.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {VENTURES.map((venture, index) => {
             const GraphicComponent = graphics[index % graphics.length];
             const ventureWithLink = venture as { name: string; subtext: string; description: string; link?: string };
             
             // Dynamic gradient cycle: Navy-to-Blue, Gold-to-Orange, Navy-to-Teal
             const gradients = [
               'from-brandNavy to-blue-900', 
               'from-brandGold to-orange-600', 
               'from-brandNavy to-teal-800'  
             ];
             const gradientClass = gradients[index % gradients.length];
             
             return (
              <div 
                key={index} 
                className="reveal bg-white overflow-hidden shadow-sm hover:shadow-xl transition-all duration-500 group rounded-lg border border-gray-100"
                style={{ transitionDelay: `${index * 0.1}s` }}
              >
                <div className="h-32 bg-gray-100 overflow-hidden relative">
                   <div className={`absolute inset-0 bg-gradient-to-r ${gradientClass} opacity-90 transition-opacity duration-500 group-hover:opacity-100`}></div>
                   
                   <GraphicComponent />

                   <div className="absolute inset-0 flex items-center justify-center p-4">
                      <h3 className="text-lg font-serif font-bold text-white/40 uppercase tracking-widest text-center transition-all duration-700 group-hover:scale-110 group-hover:text-white/60">{venture.name}</h3>
                   </div>
                   
                   <div className="absolute bottom-0 left-0 p-4 text-white translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                     <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider mb-1">
                       <Icons.Leaf />
                       <span>Impact Initiative</span>
                     </div>
                   </div>
                </div>
                
                <div className="p-6">
                  <h4 className="text-lg font-serif font-bold text-gray-900 mb-1 group-hover:text-brandGold transition-colors leading-tight">{venture.name}</h4>
                  <p className="text-gray-400 text-[10px] font-bold uppercase tracking-widest mb-3">{venture.subtext}</p>
                  <p className="text-gray-500 text-sm leading-relaxed mb-4 h-20 overflow-hidden line-clamp-3">
                    {venture.description}
                  </p>
                  <a 
                    href={ventureWithLink.link || "#"} 
                    target={ventureWithLink.link ? "_blank" : "_self"}
                    rel="noopener noreferrer"
                    className={`inline-block text-xs font-bold text-gray-900 border-b border-gray-200 hover:border-brandGold hover:text-brandGold pb-0.5 transition-all duration-300 transform group-hover:translate-x-1 ${!ventureWithLink.link ? 'opacity-50 cursor-not-allowed' : ''}`}
                    onClick={(e) => !ventureWithLink.link && e.preventDefault()}
                  >
                    Explore Impact &rarr;
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Ventures;